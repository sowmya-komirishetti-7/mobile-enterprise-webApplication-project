import { Component, OnInit } from '@angular/core';
import { MobileserviceService } from '../mobileservice.service';

@Component({
  selector: 'app-addtocart',
  templateUrl: './addtocart.component.html',
  styleUrls: ['./addtocart.component.css']
})
 export class AddtocartComponent implements OnInit {
  public productlist: any=[];
  
  constructor(private mobileser:MobileserviceService){}
 ngOnInit(): void {
      this.mobileser.getAllCart().subscribe((res:any)=>{
     let cartList:any= res;
     this.productlist=[];
     // let cartList:any;
   cartList.forEach((element:any) => {
       this.mobileser.getProductById(element.pId).subscribe((res:any)=>{
         this.productlist.push(res);
       })
      
     });
      })
 }
 removeItem(item:any){
  this.mobileser.removeCartItem(item);
 }
 emptycart(){
  this.mobileser.removeAllCart();
 }
 
}
