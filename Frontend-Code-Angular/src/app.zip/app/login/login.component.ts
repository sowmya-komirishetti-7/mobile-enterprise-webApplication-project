import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MobileserviceService } from '../mobileservice.service';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  un:any;
  pwd:any;
  users: User[]=[];
  constructor(private route:Router, private mobileser:MobileserviceService){ }

  ngOnInit(): void {
    
  }
  login(loginform: any) {
    let invalidCredentials = true;
    this.mobileser.getAllUsers().subscribe((data: any) => {
      this.users = data;
      this.users.forEach((user) => {
        // if(user.uName && user.uEmail){
        if (
          loginform.un == user.uName &&
          loginform.pwd == user.uPassword
        ) {
           invalidCredentials = false;
          this.route.navigateByUrl('userpage');
          
          if  (user.uName == 'ADMIN' && user.uPassword=='ADMIN') {
            this.route.navigateByUrl('adminpage');
           } else {
             this.route.navigateByUrl('userpage');
          }
        }
      
        
        // else{
        //   alert("Please fill all the fields..")
        // }
      });
    
      if (invalidCredentials) {
        alert('Invalid Credentials');
      }
    
    });
  
 
 
  }

  onClick(){
    this.route.navigateByUrl("register")
  }
}