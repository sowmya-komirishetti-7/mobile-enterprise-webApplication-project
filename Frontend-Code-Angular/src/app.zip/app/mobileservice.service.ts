import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Observable } from 'rxjs/internal/Observable';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class MobileserviceService {
  
  public cartItemList : any =[]
  public productList = new BehaviorSubject<any>([]);
  public search = new BehaviorSubject<string>("");

  
  

  constructor(private httpClient:HttpClient) { }
  createUser(userObj: User): Observable<any> { 
    return this.httpClient.post( '/user/list', userObj, {responseType:'text'});
  }
  getAllProducts(){
    return this.httpClient.get("/product/list");
   }
   
   saveProduct(proObj:any){
    return this.httpClient.post("/product/list",proObj);
   }
   getProductById(proId:string){
    return this.httpClient.get("/product/list/" + proId);
   }
   updateProduct(proObj:any){
    return this.httpClient.put("/product/list",proObj);
   }
   deleteProduct(proId:string){
    return this.httpClient.delete("/product/list/" + proId,{responseType : 'text'});
   }


  // getAllUsers() {
  //   return this.httpClient.get( '/user/list');
  // }
  getAllCategory(){
    return this.httpClient.get("/category/list");
   }
   
   saveCategory(catObj:any){
    return this.httpClient.post("/category/list",catObj);
   }
   getCategorytById(catId:string){
    return this.httpClient.get("/category/list/" + catId);
   }
   updateCategory(catObj:any){
    return this.httpClient.put("/category/list",catObj);
   }
   deleteCategory(catId:string){
    return this.httpClient.delete("/category/list/" + catId,{responseType : 'text'});
   }
   getAllUsers() {
    return this.httpClient.get( '/user/list');
  }

  saveUser(uObj:any){
    return this.httpClient.post("/user/list",uObj);
   }
   getUserById(uId:string){
    return this.httpClient.get("/user/list/" + uId);
   }
   updateUser(uObj:any){
    return this.httpClient.put("/user/list",uObj);
   }
   deleteUser(uId:string){
    return this.httpClient.delete("/user/list/" + uId,{responseType : 'text'});
   }
   getAllCart(){
    return this.httpClient.get("/cart/list");
   }
   
   saveCart(cartObj:any){
    return this.httpClient.post("/cart/list",cartObj);
   }
   getCartById(cartId:string){
    return this.httpClient.get("/cart/list/" + cartId);
   }
  //  updateCart(cartObj:any){
  //   return this.httpClient.put("/cart/list",cartObj);
  //  }
  //  deleteCart(cartId:string){
  //   return this.httpClient.delete("/cart/list/" + cartId,{responseType : 'text'});
  //  }

  
  
  
  getProducts(){
    return this.productList.asObservable();
  }

  setProduct(product : any){
    this.cartItemList.push(...product);
    this.productList.next(product);
  }
  addtoCart(product : any){
    this.cartItemList.push(product);
    this.productList.next(this.cartItemList);
    // this.getTotalPrice();
    console.log(this.cartItemList)
  }
  // getTotalPrice() : number{
  //   let grandTotal = 0;
  //   this.cartItemList.map((a:any)=>{
  //     grandTotal += a.total;
  //   })
  //   return grandTotal;
  // }
  removeCartItem(productlist: any){
    this.cartItemList.map((a:any, index:any)=>{
      if(productlist.pId=== a.id){
        this.cartItemList.splice(index,1);
      }
    })
    this.productList.next(this.cartItemList);
  }
  removeAllCart(){
    this.cartItemList = []
    this.productList.next(this.cartItemList);
  }
  
  
  
}

  



  

  