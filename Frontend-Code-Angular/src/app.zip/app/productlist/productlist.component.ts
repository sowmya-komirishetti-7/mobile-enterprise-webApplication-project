import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MobileserviceService } from '../mobileservice.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit{
  product:any;
  searchText:any;
  productlist: any;
  constructor(private mobileser:MobileserviceService, private router:Router){}

  ngOnInit(): void {
    this.getAllProducts();
    
  }
  getAllProducts(){
    return this.mobileser.getAllProducts().subscribe((data:any)=>{
      this.product=data;
      

      this.product.forEach((a:any )=> {
        Object.assign(a,{pQuantity:this.product.pQuantity});
        
      
      });
      
        
      console.log(data);
      
   

    });
}

  addtocart(item:any){
     this.mobileser.addtoCart(item);
    // this.mobileser.getAllCart().subscribe((res:any)=>{
    //   let cartList:any= res;
    //   this.productlist=[];
    //   // let cartList:any;
    // cartList.forEach((element:any) => {
    //     this.mobileser.getProductById(element.pId).subscribe((res:any)=>{
    //       return this.productlist.push(res);
    //     })
        
    //   });
    //    })
   this.router.navigateByUrl("/addtocart")
    
  }
  
}


