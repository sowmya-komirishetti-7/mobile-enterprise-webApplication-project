import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MobileserviceService } from '../mobileservice.service';
import { User } from '../user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  userObj: User = new User();
  
   onSuccess:boolean=false;

  constructor(private router:Router,private mobileser:MobileserviceService)
  {

  }
  ngOnInit(): void {

  }
  addUser()

  {
    if(this.userObj.uName && this.userObj.uPassword && this.userObj.uPhn && this.userObj.uEmail && this.userObj.uAddress){
          this.mobileser.createUser(this.userObj).subscribe((data)=> {
             if(data=='Success'){
              // this.onSuccess=true;
              alert("Successfully Registered..")
      setTimeout(() => {
        this.onSuccess=false;
        this.router.navigateByUrl('login');
      }, 1000);
             }
       else{
         alert(data);
       }
     console.log(this.userObj);
    },
   (error) => {
    console.log(error);
    alert(error.message);
   }
   
  );
}
  
else{
 alert("Please fill all the fields...")
  
}
  }
    onSubmit(){
  console.log(this.userObj);
  this.addUser();

}
  }



