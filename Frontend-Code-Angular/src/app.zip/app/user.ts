export class User {
    uName:any;
    uPassword:any;
    uPhn:any;
    uEmail:any;
    uAddress:any;

}
