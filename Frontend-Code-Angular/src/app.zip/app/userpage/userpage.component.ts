import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MobileserviceService } from '../mobileservice.service';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
constructor(private route: Router,private mobileservice:MobileserviceService){

}
  productlist(){
      this.route.navigateByUrl("/productlist");
  }

}


